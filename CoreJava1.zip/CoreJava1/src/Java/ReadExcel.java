package Java;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 

public class ReadExcel {
public static void main(String[] args) throws IOException {

String excelFilePath = "File.xlsx";
FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
         
 Workbook workbook = new XSSFWorkbook(inputStream);
 Sheet firstSheet = workbook.getSheetAt(0);  //Sheet1
 
 Iterator<Row> iterator = firstSheet.iterator();    // Repetetive <Row>
 
 	while (iterator.hasNext()) {   //Row  
           Row nextRow = iterator.next();    //row2
           Iterator<Cell> cellIterator = nextRow.cellIterator();// Repetetive <Column>
           	
           
           while (cellIterator.hasNext()) {  //Column
                Cell cell = cellIterator.next();   //Column1
                 
               switch (cell.getCellType()) {   //Integer
                 case STRING:
                        System.out.print(cell.getStringCellValue());
                        break;
                  case NUMERIC:
                	     System.out.print(cell.getNumericCellValue());
                        break;
                }
                System.out.print(" - ");
            }
            System.out.println();
        }
        workbook.close();
        inputStream.close();
    }
 
}