package stringprogram1;

public class StringLength1{

	 public static void main(String args[]){ 
	String s="Sachin";
	   System.out.println(s.length());//6
	  }}

