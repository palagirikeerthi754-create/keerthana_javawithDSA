package stringprogram1;

public class stringstartandend1 {
	public static void main(String args[]){
		 
		   String s="Sachin";
		   System.out.println(s.startsWith("Sa"));//true
		   System.out.println(s.endsWith("n"));//true
		 }
}
