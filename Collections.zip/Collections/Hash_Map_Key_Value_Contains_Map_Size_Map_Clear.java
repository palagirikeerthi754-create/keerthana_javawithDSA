package collections;
import java.util.HashMap;

public class Hash_Map_Key_Value_Contains_Map_Size_Map_Clear
{    
    public static void main(String[] args) 
    {
        //Creating the HashMap
         
        HashMap<Integer, Double> map = new HashMap<Integer, Double>();
         
        //Adding key-value pairs to HashMap
         
        map.put(1, 1.1);
         
        map.put(2, 2.2);
         
        map.put(3, 3.3);
         
        map.put(4, 4.4);
        
        map.put(5, 4.4);
         System.out.println(map);
        //Checking whether key '3' exist in map
         
        System.out.println(map.containsKey(3));      //Output : true
         
        //Checking whether value '3.3' exist in map
         
        System.out.println(map.containsValue(3.3));   //Output : true
        
        //Finding The Size Of The Map
        
        System.out.println(map.size());  			  //Output : 4
        
        //Clearing the Map
        
        map.clear();
        
        //Printing After Clearing
        
        System.out.println(map.size());  		
    }   
}
