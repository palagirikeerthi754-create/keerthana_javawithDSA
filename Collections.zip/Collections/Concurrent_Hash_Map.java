package collections;


import java.util.concurrent.ConcurrentHashMap;

public class Concurrent_Hash_Map extends Thread{  
    static ConcurrentHashMap<Integer,String> h=new ConcurrentHashMap<Integer,String>(); 
	
	//Concurrent HashMap will allow Multiple Threads To Work On Same Object
	
   // static HashMap<Integer,String> h=new HashMap<Integer,String>();
    //HashMap Does'nt have Multiple Thread Working on the Same Object
   
    
    public void run()   
    {   
        try  
        {   
            Thread.sleep(1000);   
            // Child thread trying to add Objects  
            // Adding new element in the object   
            h.put(103,"D");   
        }   
        catch(Exception e)   
        {   
            System.out.println("Child Thread will add objects");   
        }   
    }   
  
    public static void main(String[] args) throws InterruptedException   
    {   
        h.put(100,"X");   
        h.put(101,"Y");   
        h.put(102,"Z");   
        Concurrent_Hash_Map t=new Concurrent_Hash_Map();   
        t.start();  
        for (Object o : h.entrySet())   
        {   
            Object s=o;   
            System.out.println(s);   
            Thread.sleep(1000);   
        }   
        System.out.println(h);   
    }   
}  