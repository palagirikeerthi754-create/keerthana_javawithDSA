package collections;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

public class Hotel {
static	Scanner input =new Scanner(System.in);
public static void main(String[] args) {
	
	int rooms=10;
	HashMap<Integer,String>hotelRoom=new HashMap<Integer,String>(rooms);
	HashMap<Integer,Long>phoneNumber=new HashMap<Integer,Long>();
			

		System.out.println("Total Available Rooms"+" "+rooms);
			hotelRoom.put(1, "Siva");
			hotelRoom.put(3,"Nan");
			hotelRoom.put(5,"Nan");
			phoneNumber.put(1, 9087313266L);
			phoneNumber.put(3,9876543212L);
			phoneNumber.put(5,8925306322L);
		
			
			System.out.println("Rooms Occupied Out Of 10 Rooms:"+hotelRoom);
			System.out.println("Do You Wanna Book A Room");
			//Booking Ah Room
			

						int option =input.nextInt();
			if(option==1) {
				System.out.println("Enter the room you wanna book");
				int option2=input.nextInt();
				if(hotelRoom.containsKey(option2)==true){
					System.out.println("You Cannot Book This Room ");
				}
				else {
					if(option2<=rooms-1) {
					System.out.println("Please Enter Your Name And PhoneNumber");
					String name=input.next();
					Long phoneNumbers=input.nextLong();
					phoneNumber.put(option, phoneNumbers);
					hotelRoom.put(option2, name);
					System.out.println("You Are Addedd Into Our Hotel"+hotelRoom);
					}
					else {
						System.out.println("Our Hotel Contains Only Ten Rooms You Cannot Book Other Than the Available Rooms");
					}
				}
					}
			
			

			System.out.println("Enter The Room No You Wanna Vacate");
			int options=input.nextInt();
			if(hotelRoom.containsKey(options)) {
				System.out.println(hotelRoom.remove(options)+" "+"Has Been Vacated from Our hotel");
				System.out.println("Currently Staying Guests In Our Hotel"+hotelRoom);
			}
			
				System.out.println("Enter The NAme You Wanna Search");
				String input1=input.next();
				if(hotelRoom.containsValue(input1)) {
				
				for (Integer key:getKeys(hotelRoom,input1)) {
					System.out.println("Entered Name"+" "+input1+" is in the room number"+" "+key);
			}
			
					System.out.println("Doesn't Match To Your Search Do You Wanna Search By Phone Number");
					int answer = input.nextInt();
					if(answer==1) {
						System.out.println("Enter The PhoneNumber You Wanna Search ");
						long phno=input.nextLong();
						if(phoneNumber.containsValue(phno)) {
						
							for (Integer key:getKey(phoneNumber,phno)) {
								System.out.println("Entered Phone Number"+" "+phno+" is in the room number"+" "+key);
						}
							
							
							
						}
						else {
							System.out.println("Thankyou");
						}
					}
		
					
				
			}
				
				else {
					System.out.println("Entered Name is not in The Hotel Room Booking List");
				}
			}
  static HashSet<Integer> getKey(HashMap<Integer,Long> phoneNumber,Long value){
	HashSet<Integer>results=new HashSet<>();
	for(Map.Entry<Integer,Long>entry:phoneNumber.entrySet()) {
		if(Objects.equals(entry.getValue(), value)) {
			results.add(entry.getKey());
		}
	}
	
	return results;
		






}



	static  HashSet<Integer> getKeys(HashMap<Integer,String> hotelRoom,String value){
					HashSet<Integer>result=new HashSet<>();
					for(Map.Entry<Integer, String>entry:hotelRoom.entrySet()) {
						if(Objects.equals(entry.getValue(), value)) {
							result.add(entry.getKey());
						}
					}
					
					return result;
						
			
				


	

	}
}

